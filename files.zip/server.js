// Real-time chat server: Express serves the page, Socket.IO carries messages.
const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data.json');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 6e6 }); // allows images up to ~6 MB

app.use(express.static(path.join(__dirname, 'public')));

// ---------- tiny file-based storage (swap for MongoDB/PostgreSQL later) ----------
let db = { users: [], rooms: ['General', 'Random', 'Tech'], chats: {} };
try {
  db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) };
} catch (e) { /* first run: no file yet */ }

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFile(DB_FILE, JSON.stringify(db), () => {});
  }, 300);
}

// ---------- helpers ----------
const online = new Map(); // username -> number of open connections
const NAME_RE = /^[A-Za-z0-9 ._-]{2,20}$/;
const IMG_RE = /^data:image\/(png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$/;

const roomId = (name) => `room:${name}`;
const dmId = (a, b) => (a.toLowerCase() < b.toLowerCase() ? `dm:${a}|${b}` : `dm:${b}|${a}`);
const chatIdFor = (kind, me, to) => (kind === 'room' ? roomId(to) : dmId(me, to));

function userList() {
  return db.users.map((name) => ({ name, online: online.has(name) }));
}

// ---------- real-time events ----------
io.on('connection', (socket) => {
  let me = null;

  socket.on('join', (rawName, cb) => {
    const name = String(rawName || '').trim();
    if (!NAME_RE.test(name)) {
      return cb({ ok: false, error: 'Use 2-20 letters, numbers, spaces, dots, dashes or underscores.' });
    }
    // Same name in a different capitalisation counts as a different person: block it.
    const existing = db.users.find((u) => u.toLowerCase() === name.toLowerCase());
    const finalName = existing || name;
    if (!existing) {
      db.users.push(finalName);
      save();
    }
    me = finalName;
    online.set(me, (online.get(me) || 0) + 1);

    socket.join(`user:${me}`);
    db.rooms.forEach((r) => socket.join(roomId(r)));

    cb({ ok: true, me, users: userList(), rooms: db.rooms });
    io.emit('users', userList());
  });

  // Load saved messages for a room or a private chat
  socket.on('history', ({ kind, name }, cb) => {
    if (!me) return;
    const id = chatIdFor(kind, me, name);
    cb((db.chats[id] || []).slice(-200));
  });

  socket.on('message', ({ kind, to, text, image }, cb) => {
    if (!me) return;
    text = String(text || '').trim().slice(0, 2000);
    if (image && !IMG_RE.test(image)) image = null;
    if (!text && !image) return;
    if (kind === 'room' && !db.rooms.includes(to)) return;
    if (kind === 'dm' && !db.users.includes(to)) return;

    const msg = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      kind, to, from: me, text, image: image || null, ts: Date.now(),
    };
    const id = chatIdFor(kind, me, to);
    (db.chats[id] = db.chats[id] || []).push(msg);
    save();

    if (kind === 'room') io.to(roomId(to)).emit('message', msg);
    else io.to(`user:${to}`).to(`user:${me}`).emit('message', msg);
    if (cb) cb({ ok: true });
  });

  socket.on('typing', ({ kind, to }) => {
    if (!me) return;
    if (kind === 'room') socket.to(roomId(to)).emit('typing', { kind, to, from: me });
    else socket.to(`user:${to}`).emit('typing', { kind, to, from: me });
  });

  socket.on('createRoom', (rawName, cb) => {
    if (!me) return;
    const name = String(rawName || '').trim();
    if (!NAME_RE.test(name) || db.rooms.some((r) => r.toLowerCase() === name.toLowerCase())) {
      return cb({ ok: false, error: 'Pick a new name (2-20 letters or numbers).' });
    }
    db.rooms.push(name);
    save();
    io.sockets.sockets.forEach((s) => s.join(roomId(name))); // everyone joins new rooms
    io.emit('rooms', db.rooms);
    cb({ ok: true });
  });

  socket.on('disconnect', () => {
    if (!me) return;
    const n = (online.get(me) || 1) - 1;
    if (n <= 0) online.delete(me);
    else online.set(me, n);
    io.emit('users', userList());
  });
});

server.listen(PORT, () => console.log(`Chat running at http://localhost:${PORT}`));
