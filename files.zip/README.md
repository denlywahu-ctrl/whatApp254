# Chat app (WhatsApp-style)

Real-time chat with rooms, private one-to-one chats, photo sharing, typing
indicators, online status, unread badges and saved history.

## Run it
1. Install Node.js (v18 or newer) from https://nodejs.org
2. In this folder run:

       npm install
       npm start

3. Open http://localhost:3000 in two browser tabs, join with two different
   names, and chat.

To try it from your phone, connect it to the same Wi-Fi and open
http://YOUR-COMPUTER-IP:3000

## Files
- server.js       Socket.IO server: joins, messages, history, rooms, typing
- public/index.html   The whole interface (HTML, CSS, JavaScript)
- data.json       Created on first run; holds users, rooms and messages

## What to build next
- Passwords and login (bcrypt + JWT) so names can't be taken over
- A real database (MongoDB or PostgreSQL) instead of data.json
- Message ticks (sent / delivered / read)
- Group chats with member lists, profile photos, voice notes
- Push notifications, then wrap as an Android/iOS app (Flutter or React Native)
- End-to-end encryption (Signal protocol libraries)
